package Tema1.casosPracticos03;

public class Ejercicio18 {
    public static void main(String[] args) {
       // Haz un programa que escriba en pantalla los números del 1 al 10 utilizando un bucle while.
        int i = 1;
        while(i<=10){
            System.out.println(i);
            i++;
        }
    }
}
