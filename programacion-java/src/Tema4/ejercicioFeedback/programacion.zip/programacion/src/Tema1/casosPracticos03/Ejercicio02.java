package Tema1.casosPracticos03;

public class Ejercicio02 {
    public static void main(String[] args) {
        // Crea un programa escriba por pantalla la suma de dos números enteros
        // asignados a dos variables de ése mismo tipo.

        int numero1 = 9;
        int numero2 = 12;

        System.out.println("La suma de los numeros " + numero1 + " y " + numero2 +
                " es: " + (numero1 + numero2));


    }
}
