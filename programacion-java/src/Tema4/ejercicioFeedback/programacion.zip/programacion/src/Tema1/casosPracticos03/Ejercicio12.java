package Tema1.casosPracticos03;

public class Ejercicio12 {
    public static void main(String[] args) {
        /*
        Construye un programa que le el año de nacimiento de una persona y nos diga si es mayor de edad o no.
        Declara una constante con el año actual.

         */

        int anyoNacimiento = 1979;

        if(ANYO - anyoNacimiento >= 18){
            System.out.println("Felicidades eres mayor de edad");
        } else {
            System.out.println("Pues va ser que te fastidias y no entrar Campeon");
        }

    }
    static int ANYO = 2022;

}
