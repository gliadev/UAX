package Tema1.casosPracticos03;

public class Ejercicio10 {
    public static void main(String[] args) {
        /*
        Escribe un programa que calcule la circunferencia de un círculo.
        Declara la constante Pi y una variable que almacene el radio.
         */

        double radio = 8;
        double calculo = (2* PI * radio );
        System.out.println(calculo);

    }

    static final double PI = 3.1416;

}
