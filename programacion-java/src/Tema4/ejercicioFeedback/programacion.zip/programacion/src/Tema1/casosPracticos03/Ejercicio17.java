package Tema1.casosPracticos03;

public class Ejercicio17 {
    public static void main(String[] args) {
       // Haz un programa que escriba en pantalla los números del 1 al 10 utilizando un bucle for.

        for (int i = 1; i <= 10; i++){
            System.out.println(i);
        }
    }
}
