package Tema1.casosPracticos03;

public class Ejercicio07 {
    public static void main(String[] args) {
        /* * Declara dos variables, una String y otra numérica.
          Les asigna un nombre propio y una edad. *
         Después escribe en pantalla: * * <Nombre> <Edad> años  */

        String nombre = "Adolfo";
        int edad = 43;

        System.out.println("Hola " + nombre + " y tienes, " + edad + " años.");

    }
}
