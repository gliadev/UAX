package Tema1.casosPracticos03;

public class Ejercicio31 {
    public static void main(String[] args) {
        //Escribe un programa que calcule el producto de los 10 primeros números.

        for (int i = 0; i<=10; i++){
            System.out.println("El producto de " + i + " x " + i + " es = " + (i*i));
        }
    }
}
