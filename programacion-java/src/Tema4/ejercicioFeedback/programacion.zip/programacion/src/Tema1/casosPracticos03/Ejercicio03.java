package Tema1.casosPracticos03;

public class Ejercicio03 {
    public static void main(String[] args) {
              /*  Crea un programa que declare dos variables de tipo char
                 y las inicialice con las letras ‘N’ y ‘O’ respectivamente.
                Después debe escribirlas juntas en pantalla, de forma que escriba “NO”. */

        char primercaracter = 'N';
        char segundocaracter = 'O';

        System.out.print(primercaracter);
        System.out.println(segundocaracter);



    }
}
