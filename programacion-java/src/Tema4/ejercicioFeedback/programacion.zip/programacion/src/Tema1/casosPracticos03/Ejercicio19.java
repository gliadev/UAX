package Tema1.casosPracticos03;

public class Ejercicio19 {
    public static void main(String[] args) {
      //  Haz un programa que escriba en pantalla los números del 1 al 10 utilizando un bucle do while.

        int i = 1;

        do {
            System.out.println(i);
            i++;
        } while(i<=10);


    }
}
