package Tema1.casosPracticos03;

import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
       /* Realiza un programa que lea un nombre y escriba en pantalla:
        Hola <nombre>*/

        /*
        Scanner teclado = new Scanner(System.in);
        String nombre = teclado.next();

        System.out.println("Hola " + nombre);
                REVISAR
         */




    }
}
