package Tema1.casosPracticos03;

import java.util.Scanner;

public class Ejercicio33 {
    public static void main(String[] args) {
        // Escribe un programa que lea número hasta que se introduzca un cero. Al final,
        // debe indicarnos cuál ha sido el mayor número introducido,
        //  cuál el menor y la media aritmética de todos los introducidos.

        // math.mix
      /*  int numeroMaximo;
        int totalNumeros = 0;
        int numero;

        Scanner teclado = new Scanner(System.in);



        do {
            System.out.println("Introduce un numero (con un 0 termina el programa)");
            numero = teclado.nextInt();

            if(numero!=0){
                totalNumeros++;
                numero = Math.max(numeroMaximo);

            }
        } while (numero != 0);{
            teclado.close();
        }


    }*/
    }
}
