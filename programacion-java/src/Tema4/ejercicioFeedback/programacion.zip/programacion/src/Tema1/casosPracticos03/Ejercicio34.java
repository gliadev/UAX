package Tema1.casosPracticos03;

public class Ejercicio34 {
    public static void main(String[] args) {
            //   Escribe un programa que nos indique cuál es la factura de venta de bocadillos de un cliente,
            //    sabiendo que existen los siguientes bocadillos:
                    // - Jamón: 5,50€
                    // - Tortilla: 4€
                    // - Bacon: 4€
                    // - Lomo: 4,50€



    }
}
