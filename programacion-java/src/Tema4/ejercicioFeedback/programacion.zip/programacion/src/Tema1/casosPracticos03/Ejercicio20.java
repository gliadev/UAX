package Tema1.casosPracticos03;

public class Ejercicio20 {
    public static void main(String[] args) {
       // Escribe un programa que escriba en pantalla los números pares entre el 1 y el 100.

        for (int i = 1; i<=100; i++){
          //  System.out.println(i);
            if( i % 2 == 0){
                System.out.println(i);
            }
        }
    }
}
