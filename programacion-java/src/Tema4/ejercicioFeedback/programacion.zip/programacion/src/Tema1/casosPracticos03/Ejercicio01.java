package Tema1.casosPracticos03;

public class Ejercicio01 {
    public static void main(String[] args) {

       // Crea un programa que escriba en pantalla “¡Hola Mundo!”.
        String mensaje = "Hola Mundo";
        System.out.println(mensaje);

    }
}
