package laboratorios.laboratorio_01;

public class ejercicio01 {
}
