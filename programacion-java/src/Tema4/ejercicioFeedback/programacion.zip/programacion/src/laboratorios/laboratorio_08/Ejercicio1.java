package laboratorios.laboratorio_08;
import java.util.Arrays;

public class Ejercicio1 {
    public static void main(String[] args) {


    }
}
