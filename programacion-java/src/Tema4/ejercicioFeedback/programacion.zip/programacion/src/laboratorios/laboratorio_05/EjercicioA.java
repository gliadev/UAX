package laboratorios.laboratorio_05;

public class EjercicioA {
    public static void main(String[] args) {
        // Calcular y escribir los cuadrados
    }
}
