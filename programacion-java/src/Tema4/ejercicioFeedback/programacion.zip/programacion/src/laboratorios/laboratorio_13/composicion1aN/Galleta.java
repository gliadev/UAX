/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboratorios.laboratorio_13.composicion1aN;

/**
 *
 * @author damiansualdea
 */
public class Galleta {
    private String sabor;

    public Galleta(String sabor) {
        this.sabor = sabor;
    }

    public String getSabor() {
        return sabor;
    }
    public void setSabor(String sabor) {
        this.sabor = sabor;
    }
    
}
