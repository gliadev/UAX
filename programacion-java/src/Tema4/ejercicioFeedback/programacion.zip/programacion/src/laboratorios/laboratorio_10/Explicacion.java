package laboratorios.laboratorio_10;

public class Explicacion {
    public static void main(String[] args) {

    }
}
