package laboratorios.laboratorio_03;

public class ejercicioNotas {
    public static void main(String[] args) {
          /*

        programa que dependiendo de la nota que introduzca el docente
        nos diga si ha sido un notable, bien, suficiente, sobresaliente, suspenso, matrícula de honor
        0-4.99 no llegando al 5 suspenso
        5 - 6 no llegando al 6 es suficiente
        6 - 7 bien
        7-9 notable
        9-9.999 es sobresaliente
        10 MH
        en la condición números enteros
        */

        // ENTRADA DE DATOS
        



    }
}
