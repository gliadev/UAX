package clasesteoricas.clase03;

public class clase03 {
    public static void main(String[] args) {

        int valor = 6;

    }
}
