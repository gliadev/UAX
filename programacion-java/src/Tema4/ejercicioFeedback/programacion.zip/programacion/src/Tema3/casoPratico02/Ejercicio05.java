package Tema3.casoPratico02;

public class Ejercicio05 {
    public static void main(String[] args) {
        System.out.println("Crea un programa que declare dos arrays, uno de nombres de personas y otro de edades,\n " +
                "de 3 posiciones cada uno. Los datos deben leerse por teclado.\n" +
                "Después, recórrelos imprimiendo cada par persona-edad en una sola línea.\n");


    }
}
