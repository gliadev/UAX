package Tema3.casoPractico01;

public class Ejercicio13 {
    public static void main(String[] args) {
        System.out.println("Haz un programa que recorra los números enteros del 1 al 10 con un bucle for.\n " +
                "En cada iteración debe convertir el número a un String y concatenarlo con el anterior. \n" +
                "Finalmente, escribirá en pantalla el String obtenido con todos los números.\n");






    }
}
