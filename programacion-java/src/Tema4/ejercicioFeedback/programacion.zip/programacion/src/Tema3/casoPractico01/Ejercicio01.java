package Tema3.casoPractico01;

public class Ejercicio01 {
    public static void main(String[] args) {
        System.out.println("Asigna un string compuesto por dígitos a una variable. Después muestra su valor en pantalla,\n " +
                "concatenándolo junto a otro string entrecomillado");

        String digitos = "1979";

        System.out.println("La variable String digitos vale: " + digitos);
    }
}
