package Tema3.casoPractico01;

public class Ejercicio03 {
    public static void main(String[] args) {
        System.out.println("Escribe por pantalla una frase como esta:\n" +
                "Javier tiene 43 años.\n" +
                "En la que el nombre de la persona debe estar almacenado en una variable de tipo String\n " +
                "y la edad en otra variable, también tipo String.\n" +
                "Ten cuenta todos los espacios en blanco y el punto final.\n " +
                "Todos estos caracteres deben aparecer también por pantalla.\n");

            String nombre = "Javier";
            String edad = "43";

        System.out.println(nombre +" tiene " + edad + " años.");


    }
}
