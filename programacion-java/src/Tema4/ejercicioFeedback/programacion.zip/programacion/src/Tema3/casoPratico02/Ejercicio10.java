package Tema3.casoPratico02;

public class Ejercicio10 {
    public static void main(String[] args) {
        System.out.println("Haz un programa que busque un número introducido por el usuario (hasta que escriba el -1)\n " +
                "en un array de números declarado en el propio programa, y escriba la posición en la que se encuentra.\n" +
                "Haz búsqueda recorriendo el array con un bucle do-while.");




    }
}
