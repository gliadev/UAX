package ejerciciosPropuestos.ejerciciosBucles;

import java.util.Scanner;

public class Ejercicio23 {
    public static void main(String[] args) {
        System.out.println("Escribe un programa que lea un número n e imprima una pirámide de números con n filas\n" +
                "como en la siguiente figura:\n" +
                "1\n" +
                "121\n" +
                "12321\n" +
                "1234321");

        Scanner telcado = new Scanner(System.in);

        System.out.println("Introduce un numero");
        int numeroFilas = telcado.nextInt();



    }
}
