package ejerciciosPropuestos.ejerciciosPOO.ejerciciosVarios.perro;

import java.util.Scanner;

public class usoPerro {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        Perro perro1 = new Perro();
    }
}
