package ejerciciosPropuestos.ejerciciosBucles;

public class Ejercicio36 {
    public static void main(String[] args) {
        System.out.println("Realiza un conversor del sistema decimal al sistema de “palotes”. El 0 se representa con un – y\n" +
                "la separación entre números también con un –\n" +
                "Ejemplo: Introduzca un número entero positivo: 47021\n" +
                "El 47021 en el sistema de palotes es\n" +
                "| | | | - | | | | | | | - - | | - |");



    }
}
