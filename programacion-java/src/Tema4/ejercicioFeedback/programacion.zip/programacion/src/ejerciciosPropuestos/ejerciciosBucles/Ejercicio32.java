package ejerciciosPropuestos.ejerciciosBucles;

import java.util.Scanner;

public class Ejercicio32 {
    public static void main(String[] args) {
        System.out.println("Escribe un programa que, dado un número entero, diga cuáles son y cuánto suman los dígitos pares.\n" +
                "Los dígitos pares se deben mostrar en orden, de izquierda a derecha. \n" +
                "Usa long en lugar de int donde sea necesario para admitir números largos.\n");

        Scanner tecaldo = new Scanner(System.in);

        System.out.println("Introduce un numero entero");
        int numeroIntroducido = tecaldo.nextInt();
        
    }
}
