package ejerciciosPropuestos.ejerciciosBucles;

public class Ejercicio21 {
    public static void main(String[] args) {
        System.out.println("Muestra por pantalla todos los números primos entre 2 y 100, ambos incluidos.");

        for (int i = 2; i <= 100; i++){

        }

    }
}
