package ejerciciosPropuestos.ejerciciosPOO.ejercicioPOO02.alumnos;

public class UsoAlumno {
    public static void main(String[] args) {

        // Programar una clase principal que pruebe la funcionalidad de la clase.



    }
}
