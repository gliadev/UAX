package ejerciciosPropuestos.ejerciciosBucles;

import java.util.Scanner;

public class Ejercicio29 {
    public static void main(String[] args) {
        System.out.println("Escribe un programa que muestre por pantalla todos los números enteros positivos menores a\n" +
                "uno leído por teclado que no sean divisibles entre otro también leído de igual forma.");

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduce un numero entero");
        int numeroEntero = teclado.nextInt();

        System.out.println("Introduce el numero el numero de no divisible");
        int numeroNoDivisible = teclado.nextInt();





    }
}
