package ejerciciosPropuestos.ejerciciosPOO.ejercicioPOO02;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Random;

public class Test {
        public static void main(String[] args) {


        }
}
