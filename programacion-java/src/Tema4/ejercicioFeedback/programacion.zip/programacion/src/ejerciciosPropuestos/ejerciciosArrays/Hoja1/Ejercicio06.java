package ejerciciosPropuestos.ejerciciosArrays.Hoja1;

import java.util.Scanner;

public class Ejercicio06 {
    public static void main(String[] args) {
        System.out.println("6. Hacer un programa que lea 100 números aleatorios entre 0 y 10\n " +
                "y genere un histograma con las frecuencias de cada numero.\n" +
                "Para representar las barras del histograma se utilizara secuencias ‘*’.\n" +
                "Por ejemplo, la secuencia: 1, 1, 3, 4, 1, 3, 1, 2,......\n" +
                "generaría la siguiente salida:\n" +
                "1: ****\n" +
                "2: *\n" +
                "3: **\n" +
                "4: *\n" +
                "…........\n");

        Scanner teclado = new Scanner(System.in);





    }
}
