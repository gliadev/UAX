package ejerciciosPropuestos.ejerciciosArrays.Hoja1;

public class Ejercicio03 {
    public static void main(String[] args) {
        System.out.println("3. Hacer un programa que cree un array cuyo tamaño se pedirá por teclado y cuyo contenido serán números\n" +
                "aleatorios entre 1 y 300. Posteriormente se creara otro array que guardara aquellos números del primer array\n" +
                "que acaben en un dígito que se i ndicara por teclado (se debe controlar que se introduce un numero correcto).\n" +
                "Finalmente, mostrar por pantalla los dos arrays.");
    }
}
