package ejerciciosPropuestos.ejerciciosBucles;

public class Ejercicio31 {
    public static void main(String[] args) {
        System.out.println("Realiza un programa que pinte la letra L por pantalla hecha con asteriscos.\n " +
                "El programa pedirá la altura.\n " +
                "El palo horizontal de la L tendrá una longitud de la mitad (división entera entre 2) de la altura más uno.\n" +
                "Ejemplo: Introduzca la altura de la L: 5\n" +
                "*\n" +
                "*\n" +
                "*\n" +
                "*\n" +
                "* * *");


    }
}
