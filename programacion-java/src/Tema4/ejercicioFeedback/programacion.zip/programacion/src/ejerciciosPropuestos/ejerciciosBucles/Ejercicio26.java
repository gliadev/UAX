package ejerciciosPropuestos.ejerciciosBucles;

public class Ejercicio26 {
    public static void main(String[] args) {
        System.out.println("El programa nos debe dar la posición (o posiciones) contando de izquierda a derecha que\n" +
                "ocupa ese dígito en el número introducido.");

    }
}
