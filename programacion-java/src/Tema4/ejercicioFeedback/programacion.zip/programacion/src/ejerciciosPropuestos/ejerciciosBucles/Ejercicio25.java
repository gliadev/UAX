package ejerciciosPropuestos.ejerciciosBucles;

public class Ejercicio25 {
    public static void main(String[] args) {
        System.out.println("Realiza un programa que pida primero un número y a continuación un dígito.");


    }
}
