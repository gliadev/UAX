package Tema4.ejercicioFeedback;

public class ControlarNumeroTelefonoException extends Exception{
    public ControlarNumeroTelefonoException (String mensaje){
        super(mensaje);
    }
}
